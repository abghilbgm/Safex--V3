# Sentinel — PPE Compliance Detection System

Real-time AI-powered PPE compliance monitoring for industrial CCTV/RTSP
camera networks. Detects missing helmets, safety vests, and other PPE
from live video, logs violations with evidence snapshots to PostgreSQL,
dispatches Teams/email alerts based on rules you define, and gives you a
low-latency web dashboard grouped by physical plant area.

Pre-loaded with **16 real plant cameras** across 9 area groups.

---

## Quick Start

```bash
cp .env.example .env
docker compose run --rm ppe-app python scripts/download_model.py
docker compose up -d --build
docker compose logs -f ppe-app
```
Open **http://localhost:8080/** once you see `STARTUP COMPLETE`.

---

## Fix: "I can't see detected violations in the database / API"

### If `SELECT COUNT(*) FROM violations` in Postgres shows rows, but `/api/violations` returns "Internal Server Error"

**This was a real bug, now fixed.** PostgreSQL's `TIMESTAMPTZ` columns
(`detected_at`) come back from `asyncpg` as native Python `datetime`
objects. FastAPI's `JSONResponse` cannot serialize a raw `datetime` object
— this caused **every single call** to `/api/violations` (and related
endpoints) to fail with a 500 error, **regardless of `limit`**, even
though the data was present and correct in the database the whole time.

**The fix** (`app/db.py`): every function that returns row data now
converts `datetime`/`date`/`time` values to ISO-8601 strings via a
`_row_to_dict()` / `_rows_to_dicts()` helper before returning — so no
endpoint can hit this bug again, for any table.

**How to verify it's fixed for you:**
```bash
curl -s http://localhost:8080/api/violations?limit=10
```
Should now return actual JSON violation records (not an error). If you
were seeing 26,000+ violations in Postgres but "Internal Server Error"
from the API, this fix resolves exactly that.

### General troubleshooting order if this happens again
1. Check the live **Violation Feed** sidebar in the dashboard — does
   anything appear there in real time?
2. Check the API directly: `curl -s http://localhost:8080/api/violations?limit=10`
3. Check the database directly:
   ```bash
   docker compose exec postgres psql -U ppe_user -d ppe_compliance -c "SELECT COUNT(*) FROM violations;"
   ```
4. If the DB has data but the API errors, check server logs for the full
   traceback:
   ```bash
   docker compose logs --tail=100 ppe-app
   ```

---

## Installation

### Docker (Recommended)
```bash
cp .env.example .env
docker compose run --rm ppe-app python scripts/download_model.py
docker compose up -d --build
docker compose logs -f ppe-app
```

### Local / No Docker
```bash
psql -U postgres -c "CREATE DATABASE ppe_compliance;"
psql -U postgres -c "CREATE USER ppe_user WITH PASSWORD 'ppe_password';"
psql -U postgres -c "GRANT ALL PRIVILEGES ON DATABASE ppe_compliance TO ppe_user;"

python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
python scripts/check_db_connection.py
python scripts/download_model.py
python -m app.main
```

---

## The Dashboard, Tab by Tab

| Tab | Purpose |
|---|---|
| **Feeds** | Live annotated video grouped by area. Per-camera **↻ Reconnect** button + global "Reconnect All Cameras". |
| **Violations** | Filterable image gallery (camera/area/type). Click a thumbnail for a full-size lightbox. |
| **Analytics** | Hourly trend, violation-type breakdown, by-area-group chart. |
| **Cameras** | Add/edit/refresh/delete cameras; manage area groups; **⟲ Sync Default Cameras** button. |
| **Rules** | Create/edit/delete DB-driven alert rules. |

---

## Managing Cameras

Cameras live in PostgreSQL, not just `app/config.py` (which only supplies
the *initial seed list*). Add/edit/delete from the **Cameras** tab.
Editing a camera's RTSP URL auto-restarts just that camera's stream.

### Fixing "cameras missing from the dashboard"
`app/db.py`'s `sync_seed_data()` tops up any of the 16 seed cameras that
are missing from the database, every time the app starts — and on-demand
via the **⟲ Sync Default Cameras** button (Cameras tab) or:
```bash
curl -X POST http://localhost:8080/api/cameras/sync-seed
```
It never touches or duplicates cameras that already exist.

---

## Alert Rules

Rules live in the `alert_rules` table and are evaluated on every
confirmed violation. Fields: Camera (blank = any), Zone (blank = any,
prefix match), Violation Type (blank/`*` = any), Channels (Teams/Email),
Cooldown (seconds), Email Recipients, Enabled.

Example: *"Escalate any violation in the Substation area to Teams AND
email, 3-minute cooldown"* → Zone=`Substation`, leave Violation Type
blank, check both channels.

---

## Viewing Violation Evidence

Every confirmed violation saves an annotated JPEG snapshot. View it via:
1. **Violation Feed sidebar** — live thumbnails, click to enlarge
2. **Violations tab** — full filterable gallery
3. **Direct URL** — `GET /api/snapshot/{violation_id}`

---

## Configuration Reference

| Variable | Default | Meaning |
|---|---|---|
| `PPE_MODEL_PATH` | `models/best.pt` | YOLO weights path |
| `PPE_DEVICE` | `cpu` | `cpu` or `cuda:0` |
| `PPE_CONF_THRESHOLD` | `0.45` | Detection confidence threshold |
| `PPE_FRAME_SKIP` | `2` | Run inference every Nth frame |
| `PPE_VIOLATION_CONFIRM_FRAMES` | `5` | Consecutive frames before confirming a violation |
| `POSTGRES_HOST` | `localhost` | **Must be `postgres` for Docker Compose** (auto-set) |
| `POSTGRES_POOL_MIN`/`MAX` | `4`/`30` | Connection pool size (sized for 16+ cameras) |
| `POSTGRES_CONNECT_RETRY_SECONDS` | `60` | Startup DB connection retry window |
| `PPE_ALERTS_ENABLED` | `true` | Master alert on/off switch |
| `PPE_TEAMS_WEBHOOK` | *(empty)* | Teams incoming webhook URL |
| `PPE_SMTP_HOST`/`USER`/`PASSWORD` | *(empty)* | SMTP credentials for email alerts |
| `PPE_STATUS_UPDATE_INTERVAL` | `4` | Seconds between camera status DB writes (throttled) |
| `PPE_BROADCAST_FPS` | `12` | Dashboard video push rate per camera |

---

## REST API Reference

```
GET/POST/PUT/DELETE /api/cameras[/{camera_id}]
POST /api/cameras/{camera_id}/refresh    Force-reconnect a camera
POST /api/cameras/sync-seed              Top up missing seed cameras
GET/POST/PUT/DELETE /api/area-groups
GET /api/violations?limit=&camera_id=&violation_type=&area_group_id=
GET /api/stats?window_hours=24
GET /api/snapshot/{violation_id}
GET/POST/PUT/DELETE /api/rules
GET /api/health
WS  /ws/video/{camera_id}
WS  /ws/events
```

---

## Power BI Integration

```bash
python powerbi/build_powerbi_dataset.py --host localhost --db ppe_compliance --user ppe_user --password ppe_password --out powerbi/powerbi_data
```
Produces `violations.csv`, `daily_summary.csv`, `camera_status.csv`,
`alert_rules.csv`, `cameras.csv`, `area_groups.csv`.

---

## Customizing the Dashboard (Layout, Order, Tile Size)

**Camera display order** — `dashboard/app.js`, `renderFeedsGroupedByArea()`:
```js
const cams = groups[groupName].sort((a, b) => {
  const order = ["CAM01", "CAM02", "CAM09"]; // your desired order
  return order.indexOf(a.camera_id) - order.indexOf(b.camera_id);
});
```

**Uniform tile size** — `dashboard/style.css`, `.camera-tile canvas`:
```css
.camera-tile canvas { object-fit: cover; /* was: contain */ }
```

**Colors/theme** — CSS custom properties under `:root` in `style.css`.

---

## Troubleshooting

| Symptom | Cause | Fix |
|---|---|---|
| **`/api/violations` returns "Internal Server Error" even though `SELECT COUNT(*)` shows data** | Raw `datetime` objects couldn't be JSON-serialized | **Fixed in this version** — `_row_to_dict()` in `app/db.py` converts all timestamps to ISO strings |
| Only some cameras show up | Database only partially seeded | Cameras tab → **⟲ Sync Default Cameras**, or restart the app |
| "Application startup failed. Exiting." with no detail | Older build without full traceback logging | This build prints the full traceback to `docker compose logs -f ppe-app` |
| `InvalidPasswordError` | `.env` password mismatch vs. Postgres init | `docker compose down -v` (⚠️ deletes data) then `up -d --build` to reinit |
| Camera stuck "Reconnecting…" | Normal for PTZ pan/zoom, or real network issue | Click **↻** on that camera's tile |
| Port 8080 in use | Another process using it | Change `PPE_API_PORT` in `.env` + `docker-compose.yml` |

---

## Reliability Design Notes

- **Datetime-safe serialization** — every DB row passes through a helper
  that converts `datetime`/`date` to ISO strings before reaching any API
  response, eliminating an entire class of "works in SQL, fails via API" bugs.
- **Throttled DB status writes** — camera connectivity status is written
  at most once per `PPE_STATUS_UPDATE_INTERVAL` seconds, not every loop tick.
- **Self-healing camera worker loop** — a transient error is logged and
  the loop continues instead of permanently killing that camera's task.
- **Retry-safe violation logging** — a violation is only marked "handled"
  after its DB write succeeds; a transient failure means it's retried on
  the next frame, never silently dropped.
- **Independent camera startup** — one camera failing to start never
  blocks the others.
- **Idempotent camera seeding** — `sync_seed_data()` tops up only what's
  missing, safe to run any number of times.
- **Unbuffered startup diagnostics** — errors are printed directly to
  `stderr` with `flush=True`, bypassing Python's logging module (which
  Uvicorn reconfigures), plus `PYTHONUNBUFFERED=1` at the container level.

---

## Project Structure

```
ppe_compliance_system/
├── README.md
├── .env.example, requirements.txt, Dockerfile, docker-compose.yml
├── run_server.bat, run_server_hidden.vbs
├── app/
│   ├── config.py            SEED_CAMERAS/SEED_AREA_GROUPS + tunables
│   ├── db.py                  PostgreSQL layer + sync_seed_data() + datetime-safe serialization
│   ├── camera_manager.py        Per-camera worker lifecycle (self-healing)
│   ├── stream_handler.py         Threaded RTSP frame grabber
│   ├── detector.py                YOLO model wrapper
│   ├── compliance_engine.py        PPE-to-person matching + violation tracking
│   ├── rules_engine.py              Alert rule matching + cooldowns
│   ├── alert_manager.py              Teams/email dispatch
│   ├── ws_hub.py                      Zero-backlog WebSocket broadcast hub
│   └── main.py                         FastAPI app: all REST + WebSocket routes
├── dashboard/                    index.html, style.css, app.js (no build step)
├── scripts/                       download_model, train, seed_rules, quick_test, check_db_connection
├── powerbi/                        build_powerbi_dataset.py
└── models/, snapshots/
```

---

## Operational Notes & Limitations

- Decision-support tool — keep human review in the loop for disciplinary actions.
- Fine-tune the model on your own footage (`scripts/train.py`) for best accuracy.
- Ensure camera footage usage complies with your organization's privacy policies.
- Schedule regular `pg_dump` backups (or back up the `ppe-postgres-data` Docker volume).
