"""stream_handler.py — threaded RTSP frame grabber with automatic reconnect."""
import cv2, time, threading, logging
logger = logging.getLogger("ppe.stream")

class RTSPStream:
    def __init__(self, camera_id, rtsp_url, reconnect_delay=5):
        self.camera_id = camera_id; self.rtsp_url = rtsp_url; self.reconnect_delay = reconnect_delay
        self._cap = None; self._frame = None; self._lock = threading.Lock()
        self._running = False; self._thread = None; self.last_frame_time = 0.0; self.connected = False
    def start(self):
        self._running = True; self._thread = threading.Thread(target=self._update_loop, daemon=True); self._thread.start(); return self
    def stop(self):
        self._running = False
        if self._thread: self._thread.join(timeout=2)
        if self._cap: self._cap.release()
    def _open(self):
        cap = cv2.VideoCapture(self.rtsp_url, cv2.CAP_FFMPEG); cap.set(cv2.CAP_PROP_BUFFERSIZE, 1); return cap
    def _update_loop(self):
        while self._running:
            if self._cap is None or not self._cap.isOpened():
                self._cap = self._open()
                if not self._cap.isOpened():
                    self.connected = False; time.sleep(self.reconnect_delay); continue
                self.connected = True
            try: ok, frame = self._cap.read()
            except Exception: ok, frame = False, None
            if not ok or frame is None:
                self.connected = False; self._cap.release(); self._cap = None; time.sleep(self.reconnect_delay); continue
            with self._lock: self._frame = frame; self.last_frame_time = time.time()
    def read(self):
        with self._lock: return None if self._frame is None else self._frame.copy()
    def is_stale(self, max_age_seconds=10.0):
        if self.last_frame_time == 0: return True
        return (time.time() - self.last_frame_time) > max_age_seconds
