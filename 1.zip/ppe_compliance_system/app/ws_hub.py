"""ws_hub.py — zero-backlog WebSocket broadcast hub."""
import asyncio, logging
from typing import Dict, Set
logger = logging.getLogger("ppe.ws_hub")

class _LatestOnlyQueue:
    def __init__(self): self._queue = asyncio.Queue(maxsize=1)
    async def put(self, item):
        if self._queue.full():
            try: self._queue.get_nowait()
            except asyncio.QueueEmpty: pass
        await self._queue.put(item)
    async def get(self): return await self._queue.get()

class WebSocketHub:
    def __init__(self):
        self._video_subscribers: Dict[str, Set[_LatestOnlyQueue]] = {}
        self._event_subscribers: Set[_LatestOnlyQueue] = set()
        self._lock = asyncio.Lock()
    async def subscribe_video(self, camera_id):
        q = _LatestOnlyQueue()
        async with self._lock: self._video_subscribers.setdefault(camera_id, set()).add(q)
        return q
    async def unsubscribe_video(self, camera_id, q):
        async with self._lock:
            subs = self._video_subscribers.get(camera_id)
            if subs and q in subs: subs.discard(q)
    async def broadcast_frame(self, camera_id, jpeg_bytes):
        subs = self._video_subscribers.get(camera_id)
        if not subs: return
        for q in list(subs): await q.put(jpeg_bytes)
    async def subscribe_events(self):
        q = _LatestOnlyQueue()
        async with self._lock: self._event_subscribers.add(q)
        return q
    async def unsubscribe_events(self, q):
        async with self._lock: self._event_subscribers.discard(q)
    async def broadcast_event(self, event):
        for q in list(self._event_subscribers): await q.put(event)
    def stats(self):
        return {"video_subscriber_counts": {cid: len(s) for cid, s in self._video_subscribers.items()}, "event_subscribers": len(self._event_subscribers)}

hub = WebSocketHub()
